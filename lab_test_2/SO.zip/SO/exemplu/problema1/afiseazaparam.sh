#!/bin/bash

#Verificam daca numarul de parametrii este 13
if [ "$#" -ne 13 ]; then
	echo "Eroare: Trebuie specificati exact 13 pamatrii."
	exit 1
fi

#Afisam parametrii primiti
echo "Parametrii introdusi sunt: "
for i in {1..13};do
	echo "Parametrul $i: ${!i}"
done

