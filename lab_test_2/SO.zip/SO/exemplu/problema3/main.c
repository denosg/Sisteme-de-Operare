#include <stdio.h>
#include "matrice_math.h"


void afiseazaMatrice(int matrice[3][3]) {
    int i, j;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("%d ", matrice[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

int main() {

    int matrice1[3][3] = {
            {9, 8, 7},
            {6, 5, 4},
            {3, 2, 1}
    };

    int matrice2[3][3] = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
    };


    int suma[3][3] = {
	{0, 0, 0},
        {0, 0, 0},
        {0, 0, 0}
    };

     int produs[3][3] = {
	{0, 0, 0},
        {0, 0, 0},
        {0, 0, 0}
    };

    adunareMatrice(matrice1, matrice2, suma);
    afiseazaMatrice(suma);

    inmultesteMatrice(matrice1, matrice2, produs);
    afiseazaMatrice(produs);


    return 0;
}
