#ifndef MATRICE_MATH_H
#define MATRICE_MATH_H

void adunareMatrice(int a[3][3], int b[3][3], int rez[3][3]);
void inmultesteMatrice(int a[3][3], int b[3][3], int rez[3][3]);


#endif 

