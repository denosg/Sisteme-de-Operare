#include "matrice_math.h"


void adunareMatrice(int a[3][3], int b[3][3], int rez[3][3]) {

    int i, j;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            rez[i][j] = rez[i][j] + (a[i][j] + b[i][j]);
        }

    }
}

void inmultesteMatrice(int a[3][3], int b[3][3], int rez[3][3]) {

    int i, j, k;


    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            for (k = 0; k < 3; k++) {
                rez[i][j] = rez[i][j] + (a[i][k] * b[k][j]);
            }
        }

    }
}
