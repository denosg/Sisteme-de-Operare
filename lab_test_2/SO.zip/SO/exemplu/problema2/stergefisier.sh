#!/bin/bash

#Verificam daca a fost specificata cel putin o extensie
if [ "$#" -lt 1 ]; then
	echo "Eroare: Trebuie sa specificati cel putin o extensie."
	echo "Utilizare: $0 extensie1 [extensie2 ...... extensieN]"
	exit 1
fi

#Iteram print toate extensiile primite ca parametrii
for extensie in "$@"; do
	echo "Se sterg fisierele cu extensia .$extensie din directorul curent..."
	rm -f -- *."$extensie" 2>/dev/null
done


echo "Operatiunea a fost finalizata"
